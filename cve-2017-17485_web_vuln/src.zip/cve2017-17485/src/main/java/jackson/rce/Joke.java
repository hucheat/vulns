package jackson.rce;

class Joke {
    public String title;
    public String context;
}
