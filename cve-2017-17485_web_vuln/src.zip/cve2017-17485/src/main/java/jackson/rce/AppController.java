package jackson.rce;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.IOException;
import java.util.Map;

@Controller
public class AppController {
       @RequestMapping(value = "rce",method = RequestMethod.POST)
        public String vuln(@RequestBody String json, Map<String ,String> map) throws IOException {
            ObjectMapper om = new ObjectMapper();
            om.enableDefaultTyping();
            App app = om.readValue(json, App.class);
            Joke j = (Joke)app.obj;
            map.put("title",j.title);
            return "app";
    }
}
