package jackson.rce;
public class App {
    public int id;
    public Object obj;
}
