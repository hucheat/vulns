# springmvc
最最简单的 springmvc 例子

导入此 Maven 项目，会自动下载相关 jar 包

启动后可通过访问 http://localhost:8080/springmvc/index 查看效果

如果浏览器中显示 Spring Demo Success! 字样，则表示成功

![](http://images.cnblogs.com/cnblogs_com/zawier/998251/o_%e6%8d%95%e8%8e%b7.PNG)

如有问题，欢迎提 Issues 